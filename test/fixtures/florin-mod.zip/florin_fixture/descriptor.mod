name="Florin Fixture"
version="7.0"
dependencies={ "Base Mod" }
replace_path="events/fixture"
replace_path="common/fixture"
